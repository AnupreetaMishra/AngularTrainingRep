
##One time Setup:

- Clone the repository then cd into main folder(i.e 'AngularTesting')
- npm install
- bower install
- npm install -g gulp bower
- npm install -g protractor
- webdriver-manager update

##Available Commands:

- Serve Angular app
   - "gulp connect"

- Unit test
   - "karma start"
    
- e2e test 
   - "webdriver-manager start"  
   - "protractor conf.js" - new command line