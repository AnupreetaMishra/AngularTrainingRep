angular.module('app').service('studentService', function ($q, $http) {


    var students = [
        {
            id: 0,
            firstName: "Anupreeta",
            lastName:"Mishra",
            email:"mishra.anu@anu.anu",
            phone:8550984794,
            gender:"Female",
            location:"India",
            active: true
        },
        {
            id: 1,
            firstName: "Amruta",
            lastName:"Shinde",
            email:"shinde.shinde@shinde.shinde",
            phone:9324863797,
            gender:"Female",
            location:"America",
            active: false
        },
        {
            id: 2,
            firstName: "Shoumit",
            lastName:"Karnik",
            email:"karnik.karnik@karnik.karnik",
            phone:8550984794,
            gender:"Female",
            location:"India",
            active: true
        },
        {
            id: 3,
            firstName: "Akshay",
            lastName:"Manoj",
            email:"manoj.manoj@manoj.manoj",
            phone:8550984794,
            gender:"Female",
            location:"India",
            active: true
        },
        {
            id: 4,
            firstName: "Mukul",
            lastName:"Tilak",
            email:"tilak.tilak@tilak.tilak",
            phone:8550984794,
            gender:"Female",
            location:"India",
            active: false
        }
    ];

     this.search = function (firstNameKey, studentArray) {
         for (var count = 0; count < studentArray.length; count++) {
             if (studentArray[count].id === parseInt(firstNameKey)) {
                 return studentArray[count];
             }
         }
     }; 


    this.getStudentById = function(id) {
        var deferral = $q.defer();
        var rec = this.search(id, students);
        deferral.resolve(rec);
        return deferral.promise;
    };
    this.addStudent = function (student) {
        var deferral = $q.defer();
        student.id = students.length;
        deferral.resolve(students.push(student));
        return deferral.promise;
    };
    this.getStudents = function () {
        var deferral = $q.defer();
        deferral.resolve(students);
        return deferral.promise;
    };
    this.deleteRecord = function (id) {
        var i = 0;
        students.forEach(function (element) {         
            if (element.id === id) {
                students.splice(i, 1);
            }
            i = ++i;
        }, this);
        return students;
    };
    this.deleteStudent =function (id){
         var deferral = $q.defer();
        deferral.resolve(this.deleteRecord(id));
        return deferral.promise;
    };

    this.updateStudent = function (rec){
        var deferral = $q.defer();
        var student = this.search(rec.id,students);
        student.firstName = rec.firstName;
       // student.year = rec.year;
        student.active = rec.active;
        student.lastName=rec.lastName;
        student.email=rec.email;
        student.gender=rec.gender;
        student.phone=rec.phone;
        student.location=rec.location;
        deferral.resolve(rec);
        return deferral.promise;
    };
});