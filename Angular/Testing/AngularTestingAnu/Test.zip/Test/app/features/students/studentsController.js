angular.module('app').controller('studentsController', function(studentService) {
    var vm = this;
    vm.gridItems = [];
    vm.searchInput = '';
    vm.label = "List of Students"; 
    vm.deleteStudent = function (item){
        studentService.deleteStudent(item.id).then(function (){
        });
    };

    vm.getStudents = function () {
        studentService.getStudents().then(function (data) {
            vm.gridItems = data;
        });
    };
    vm.getStudents();
});
