describe('Testing Student controller', function () {

 var students = [
        {
            id: 0,
            firstName: "Anupreeta",
            lastName:"Mishra",
            email:"mishra.anu@anu.anu",
            phone:8550984794,
            gender:"Female",
            location:"India",
            active: true
        },
        {
            id: 1,
            firstName: "Amruta",
            lastName:"Shinde",
            email:"shinde.shinde@shinde.shinde",
            phone:9324863797,
            gender:"Female",
            location:"America",
            active: false
        }
    ];

    beforeEach(module('app'));

    var controller;
    var scope;
    var jzAccountService;

    beforeEach(angular.mock.module(function ($provide) {
        $provide.service('studentService', function mockService($q, $timeout) {
            return {
                getStudents: function () {
                    var deferral = $q.defer();
                    deferral.resolve(students);
                    return deferral.promise;
                }
            };
        });
    }));

    beforeEach(angular.mock.inject(function (_$controller_, $rootScope, studentService) {
        scope = $rootScope.$new();
        studentService = studentService;
        controller = _$controller_('studentsController', {});
    }));

    it('should have a studentsController controller', function () {
        expect(controller).toBeDefined();
        expect(controller).not.toBe(null);
    });
});
