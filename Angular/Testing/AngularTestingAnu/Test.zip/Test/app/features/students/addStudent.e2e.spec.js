describe('Protractor Demo App', function() {
  var firstName = element(by.model('routeVM.newstudent.firstName'));
  var lastName = element(by.model('routeVM.newstudent.lastName'));
  var email=element(by.model('routeVM.newstudent.email'));
  var phone=element(by.model('routeVM.newstudent.phone'));
  var gender=element(by.model('routeVM.newstudent.gender'));
  var location=element(by.model('routeVM.newstudent.location'));
  var active=element(by.model('routeVM.newstudent.active'));
  var goAdd = element(by.id('add'));
  var latestResult = element(by.binding('latest'));
  var history = element.all(by.repeater('item in routeVM.gridItems'));
  var goUpdate=element(by.id('update'));
  var goDelete=element(by.buttonText('Delete'));
  //var goDelete=elemement
  

  function add(a, b,c,d,e,f,g) {
    firstName.sendKeys(a);
    lastName.sendKeys(b);
    email.sendKeys(c);
    phone.sendKeys(d);
    gender.sendKeys(e);
    location.sendKeys(f);
    active.sendKeys(g);
    goAdd.click();
  }
    function update(a) {
    firstName.clear();
    firstName.sendKeys(a);
    //expect(element(by.model('routeVM.newstudent.firstName')).getAttribute('value')).toEqual('Frank');
    // lastName.sendKeys(b);
    // email.sendKeys(c);
    // phone.sendKeys(d);
    // gender.sendKeys(e);
    // location.sendKeys(f);
    // active.sendKeys(g);
    goUpdate.click();
  }
  function deleting(item){
    goDelete.click();
  }

  // beforeEach(function() { 
  //       browser.get('#');
  // });

  it('should have a Records', function() {   
    browser.get('#');
    element(by.id('student')).click();
    var history = element.all(by.repeater('item in routeVM.gridItems'));
    expect(history.count()).toEqual(5);
  });

   it('should have add record', function() {
    element(by.id('student')).click();
    expect(history.count()).toEqual(5);
    element(by.id('newStudent')).click();
    add('Anu','Mis','m.m@m',1234567890,'Female','India',false);
    expect(history.count()).toEqual(6);
    // expect(history.get(firstName).getText()).toEqual('Anu');
  });
  it('should have edit record',function(){
     element(by.id('student')).click();
    element( by.css('[ng-href*="#EditStudent/2"]')).click();
    update('Frank');
    expect(element( by.css('[ng-href*="#EditStudent/2"]')).getText()).toEqual('Frank');
  });
  it('should have delete record',function(){
     element(by.id('student')).click();
    expect(history.count()).toEqual(6);
    deleting(4);
    expect(history.count()).toEqual(5);
  });
    

});