describe('Testing Add Edit Student controller', function () {

    var students = [
        {
            id: 0,
            firstName: "Anupreeta",
            lastName: "Mishra",
            email: "mishra.anu@anu.anu",
            phone: 8550984794,
            gender: "Female",
            location: "India",
            active: true
        },
        {
            id: 1,
            firstName: "Amruta",
            lastName: "Shinde",
            email: "shinde.shinde@shinde.shinde",
            phone: 9324863797,
            gender: "Female",
            location: "America",
            active: false
        }
    ];

    search = function (nameKey, myArray) {
        for (var count = 0; count < studentArray.length; count++) {
            if (studentArray[count].id === parseInt(firstNameKey)) {
                return studentArray[count];
            }
        }
    };

    beforeEach(module('app'));

    var controller;
    var scope;
    var jzAccountService;

    beforeEach(angular.mock.module(function ($provide) {
        $provide.service('studentService', function mockService($q, $timeout) {
            return {
                addStudent = function (student) {
                    var deferral = $q.defer();
                    student.id = students.length;
                    deferral.resolve(students.push(student));
                    return deferral.promise;
                },
                updateStudent = function (rec) {
                    var deferral = $q.defer();
                    var student = search(rec.id,students);
                    student.firstName = rec.firstName;
                    // student.year = rec.year;
                    student.active = rec.active;
                    student.lastName = rec.lastName;
                    student.email = rec.email;
                    student.gender = rec.gender;
                    student.phone = rec.phone;
                    student.location = rec.location;
                    deferral.resolve(student);
                    return deferral.promise;
                }
            };
        });
    }));

    beforeEach(angular.mock.inject(function (_$controller_, studentService) {
        studentService = studentService;
        controller = _$controller_('addStudentController', {});
    }));

    it('should add a studentsController controller', function () {
        var rec =
            {

                id: 2,
                firstName: "Shoumit",
                lastName: "Karnik",
                email: "karnik.karnik@karnik.karnik",
                phone: 8550984794,
                gender: "Female",
                location: "India",
                active: true
            };
        controller.addShow(rec);
        expect(students.length).toBe(3);
    });
    it('should update studentsController controller', function () {
        var rec = {
            id: 0,
            firstName: "Anu",
            lastName: "Mishra",
            email: "mishra.anu@anu.anu",
            phone: 8550984794,
            gender: "Female",
            location: "India",
            active: false
        };
        controller.updateShow(rec);
        var updatedRecord = search(rec.id, students);
        expect(updatedRecord.firstName).toBe('Anu');
        expect(updatedRecord.active).toBe(false);
    });
});
