angular.module('app').controller('addStudentController', function(studentService, $routeParams, $location, $filter) {
    var vm = this; 
    vm.label = "Add/Edit Students";
    vm.id = $routeParams.id;
    vm.newstudent = {};
    if (vm.id) {
        studentService.getStudentById(vm.id).then(function (data) {
            vm.newstudent = data;
        });
    }
    vm.addShow = function (show) {        
        studentService.addStudent(show).then(function () {
            vm.newstudent = {};
            $location.path('/Students');
        });
    };
    vm.updateShow = function (show) {
        studentService.updateStudent(show).then(function () {
            vm.newstudent = {};
            $location.path('/Students');
        });
    };
});