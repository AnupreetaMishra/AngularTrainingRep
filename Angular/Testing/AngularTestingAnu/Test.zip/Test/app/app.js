var sampleApp = angular.module('app', ['ngRoute']);

sampleApp.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
            when('/Students', {
                templateUrl: 'features/students/students.html',
                controller: 'studentsController',
                controllerAs: 'routeVM',
            }).
            when('/AddNewStudent', {
                templateUrl: 'features/students/addstudent.html',
                controller: 'addStudentController',
                controllerAs: 'routeVM',
            }).
             when('/EditStudent/:id', {
                templateUrl: 'features/students/addstudent.html',
                controller: 'addStudentController',
                controllerAs: 'routeVM',
            }).
            otherwise({
                redirectTo: '/Students'
            });
    }]);