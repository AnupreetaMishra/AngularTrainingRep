angular.module('mainApp').controller('viewStudentsController', function ($scope) {
    $scope.message = "This page will be used to display all the students";
}); 