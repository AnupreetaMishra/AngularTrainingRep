angular.module('mainApp').controller('addStudentsController', function ($scope) {
  $scope.message = "This page will be used to display add student form";
}); 